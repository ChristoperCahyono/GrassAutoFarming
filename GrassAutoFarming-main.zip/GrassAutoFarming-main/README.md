# BOT GRASS AUTO FARMING

# Register
- https://app.getgrass.io/register/?referralCode=AYtNN0N1D0pzSCc

# Command
- git clone https://github.com/AirDropFamilyIDN/GrassAutoFarming.git
- cd GrassAutoFarming
- pip install -r requirements.txt
- python run_http.py
- python run_socks4.py
- python run_socks5.py

# get USERID
- Press F12 => Console => ketik allow pasting => trus paste localStorage.getItem('userId')
